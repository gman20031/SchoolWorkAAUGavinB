#pragma once

#include "..\level\LevelData.h"
#include "Entity.h"

class Player : Entity 
{

public:
	static constexpr char kPlayerChar = '@';

};